# funcsforspo_l - Funcoes para Selenium; Python; Openpyxl; SQLite3

## pip install funcsforspo_l | NECESSÁRIO PYTHON 3.10

Aqui voce achara funcoes produzidas para ter maior agilidade nos desenvolvimentos nas tecnologias abaixo:

* Selenium
  * Existem diversas funcoes em pt-br que vao te ajudar a desenvolver os seus projetos mais rapidamente em selenium
* Openpyxl (ainda em desenvolvimento para mais funcoes)
  * Algumas funcoes que minimizarao o trabalho pesado de mexer com openpyxl
* Python
  * Funcoes criadas para o Python, como excluir varios arquivos, criar, verificar se um programa / executavel esta aberto, entre outras funcionalidades

## Instalacao

pip install FuncsForSPO em seu ambiente virtual e pronto!

Powered By [https://github.com/gabriellopesdesouza2002](https://github.com/gabriellopesdesouza2002)

# Current Version -> 1.0.0

version==1.0.0 -> Primeira implementação
