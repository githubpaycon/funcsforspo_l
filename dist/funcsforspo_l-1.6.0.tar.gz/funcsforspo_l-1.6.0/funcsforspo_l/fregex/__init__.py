"""
Funções Regex
"""
