"""
Funções criadas por Gabriel Lopes de Souza

Funções para envio de e-mails
"""
