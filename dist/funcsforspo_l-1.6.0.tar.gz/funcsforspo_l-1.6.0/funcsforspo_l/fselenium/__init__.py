"""
Funções Selenium
"""
