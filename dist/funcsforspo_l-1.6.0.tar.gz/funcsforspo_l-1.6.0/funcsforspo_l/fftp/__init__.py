"""
Funções criadas por Gabriel Lopes de Souza

Funções para conexões FTP
"""
