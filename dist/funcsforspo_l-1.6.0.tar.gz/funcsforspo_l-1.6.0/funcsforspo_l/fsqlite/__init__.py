"""
Funções SQLITE
"""
