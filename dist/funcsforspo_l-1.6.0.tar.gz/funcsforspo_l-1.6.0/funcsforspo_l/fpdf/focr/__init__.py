"""
DIREITOS RESERVADOS / RIGHTS RESERVED / DERECHOS RESERVADOS

https://online2pdf.com/pt/converter-pdf-para-txt-com-ocr
"""